# db.posinfo.find({"position_url":{"$in":['https://www.zhipin.com/job_detail/1407293933.html']}})

# db.posinfo_refine.find({"position_url":{"$in":['https://www.liepin.com/job/197554328.shtml']}})
from database import DBPOS as table

# 通过职位url 查找某个数据
debugurl = 'https://www.liepin.com/company/8323780/'
debugurl = 'https://www.liepin.com/job/197624008.shtml'

'''
{'position_url': {'$regex': 'zhipin'}}
'''

pipeline = [
        {'$match': {'position_url': {'$in': [debugurl]}}},
    ]
for item in table.aggregate(pipeline):
    for key in item.keys():

        print(key ,' : ', item[key])






