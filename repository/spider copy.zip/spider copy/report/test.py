
keys = ['机器学习', '人工智能']
class LagouSpider():
    name = "lagou"
    allowed_domains = ["lagou.com"]
    url = "https://www.lagou.com/jobs/"
    # start_url = []
    # for key in keys:
    #     start_url.append(url.format(key))

    def start_requests(self):
        for key in keys:
            for pn in range(1, 10):
                header = {
                    # 'first': 'false',
                    'pn': pn,
                    'kd': key,
                }
                # if pn == 1: header['first'] = 'true'


if __name__ == "__main__":

    instance = LagouSpider()
    instance.start_requests()
