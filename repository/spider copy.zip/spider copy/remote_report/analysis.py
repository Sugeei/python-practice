# 2017.04.08
# 优化, 改写成类, 将公司名称列提取出来, 分析公司分布情况
import time, re
from datetime import datetime
from xlswriter import excelwriter
from columnlist import column
from pipeline import pipeline
from database import DBPOS as table
import csv

class mlearning(object):

    def __init__(self, pipeline, table):

        self.data = table.aggregate(pipeline)

    def get_company(self):
        companylist = []
        for item in self.data:
            companylist.append(item['comany_name'])

        return companylist

    def learn_company(self):
        complist = self.get_company()
        with open('companylist.csv', 'w') as f:
            writer = csv.writer(f)
            writer.writerow(complist)



report = mlearning(pipeline, table)

report.learn_company()


