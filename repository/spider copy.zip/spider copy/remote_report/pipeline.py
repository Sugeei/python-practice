#!usr/bin/env python
# #_*_ coding: utf-8 _*_

import time, re
from datetime import datetime

# import pymongo
# import csv

# from companylist import companies

from columnlist import column
columnlist = {}

for item in column.split(','):
    columnlist[item] = 1
columnlist['_id'] = 0


# 2014.04.08
# 定义pipeline, 筛选出符合下面条件的 职位信息, 用于将这些职位信息的crawldetailflag字段标记为True, 进而访问其url, 提取详细职位描述。


sort = {'$sort': {'year_experience':1}},#{'age' : {'$in' : [10, 22, 26]}}


# Todo pipeline 去重
match = [
    {'$match': {'job_description': {'$exists': 1}}},
    # {'$match': {'qualification': {'$exists': 1}}},


    # {'$match': {'publish_time': {'$gt': '2017-04-02'}}},
    {'$match': {'publish_time': {'$regex': '20'}}},
    {'$match': {'crawldetailflag': {'$exists': False}}},
    # {'$match': {'salary': {'$regex': '\d'}}},
    {'$match': {'location': {'$in': ['北京', '上海', '广州', '深圳', '杭州']}}},
    # {'$match': {'company_name': {'$in': companies}}},
    # {'$match': {'original_site_name': {'$in': ['猎聘','']}}},
    {'$match': {'degree': {'$regex': "[本硕]"}}},
    # {'$match': {'year_experience': {'$regex': "[3-4]{1}"}}},
    {'$match': {'position_name': {'$regex': "[数据]"}}},

    {'$project': columnlist},

]
'''

['人工智能软件开发工程师', '10000-20000', '数据堂', '北京', '1年工作经验', '2017/04/04', '', '', 'https://www.liepin.com/job/197803016.shtml', False, '']
['人工智能软件开发工程师', '10000-20000', '数据堂', '北京', '1年工作经验', '2017/04/05', '', '', 'https://www.liepin.com/job/197803016.shtml', False, '']
['人工智能软件开发工程师', '10000-20000', '数据堂', '北京', '1年工作经验', '2017/04/07', '', '', 'https://www.liepin.com/job/197803016.shtml', False, '']
'''

from datetime import datetime, timedelta

curdate = datetime.now()

mindate = curdate - timedelta(days=2)

mindate = mindate.strftime('%Y-%m-%d')

citylist = ['北京', '上海', '广州', '深圳', '杭州']
citylist = ['北京', '上海', '深圳', '杭州']


pipeline = [
    # match
    {'$match': {'publish_time': {'$gt': mindate}}},
    {'$match': {'publish_time': {'$lt': curdate.strftime('%Y-%m-%d')}}},   # 规避问题数据
    {'$match': {'publish_time': {'$regex': '20'}}},

    # 匹配 crawldetailflag 为False 的row
    {'$match': {'positionstatus': {'$nin':['close']}}},  # positionstatus 不为close
    {'$match': {'crawldetailflag': {'$in':[False]}}},  # 筛选出没有 crawldetailflag 字段的数据
    # {'$match': {'job_description': {'$exists':1}}},  # 筛选出没有 crawldetailflag 字段的数据
    {'$match': {'degree': {'$regex': "[本硕]"}}},
    # {'$match': {'year_experience': {'$regex': "[3-4]{1}"}}},
    # {'$match': {'position_name': {'$regex': "[数据]"}}},
    {'$match': {'position_name': {'$regex': "[数据]"}}},

    # 增加薪水> x 作为筛选条件
    # {'$match': {'company': {"$in": regcomp}}},
    # {'$limit': 1},
    # {'$group': {'_id': {'position_url': 1}, }},

    # sort
    {'$sort': {'year_experience': 1}},
    {'$project': columnlist},

    # {'$group':{'position_url':"$version",}},
]
#
pipeline = []
