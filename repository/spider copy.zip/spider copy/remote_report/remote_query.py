
import time, re
from datetime import datetime
import pymongo

from xlswriter import excelwriter
# from mongoconn import mongoset, mongoinsert,mongoupdate, TPOS

# 2017.04.08
# 提取 最近7天的职位数据

redata = []


complist = []
#
from columnlist import column
from pipeline import pipeline
from database import DBPOS as table

for item in table.aggregate(pipeline):
    item['position_name'] = ''.join(item['position_name'].split())
    # positionurl.append(item['position_url'])

    #
    # try:
    #     item['job_descri'] = item['qulification']
    #     # detail = item['job_descri'].split('：')
    #     pt = re.compile(u'[任职位]{2}要求：(.*)')
    #     item['qulification'] = pt.search(item['qulification']).group(1)
    #     pt = re.compile(u'工作职责：(.*)[任职位]{2}要求')
    #     item['job_descri'] = pt.search(item['job_descri']).group(1)
    #     # qualification
    #     # job_decri
    #     # item['qualification'] = pt.search(item['qualification']).group(1)
    # except:
    #     pass

    # 处理工作经验
    # pt = re.compile(u'(\d*)')
    # item['year_experience'] = pt.search(item['year_experience']).group(1)


    # 处理薪水, 换算成月薪
    salary = str(item['salary'])
    pt = re.compile(u'(\d*)万')
    if pt.findall(salary):
        match = pt.search(salary)
        smin = int(match.group(1)) / 12 * 10000
        item['salary'] = str(int(smin))

    pt = re.compile(u'(\d*)-(\d*)万')
    if pt.findall(salary):  # .encode('utf-8').decode('utf-8')
        match = pt.search(salary)
        smin = int(match.group(1)) / 12 * 10000
        smax = int(match.group(2)) / 12 * 10000
        item['salary'] = str(int(smin)) + '-' + str(int(smax))


    # 处理日期格式
    # try:
    #     item['publish_time'] = time.strptime(item['publish_time'], '%Y-%m-%d').strftime('%Y/%m/%d')
    # except:
    #     pass
    # # 处理公司行业分隔符
    # try:
    #     item['industry'] = ','.join(item['industry'].split('/'))
    # except:
    #     pass

    row = []

    for key in column.split(','):
        try:
            row.append(item[key])

        except:
            row.append('')

    # if not row[0] or row[0] != 'None':
    redata.append(row)
    print(row)

print('Total positions are :', len(redata))


time = datetime.now()
filename = 'position' + time.strftime('%Y-%m-%d') + '.xlsx'

excelwriter(column.split(','), redata, filename)



