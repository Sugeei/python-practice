
column = 'position_name,salary,' \
         'company_name,' \
         'location,' \
         'year_experience,' \
         'publish_time,' \
         'position_url,temptation,company_icon,job_description' #crawldetailflag'#,job_description' #,qualification'
