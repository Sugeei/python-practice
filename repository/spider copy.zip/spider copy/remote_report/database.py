#!usr/bin/env python
#_*_ coding: utf-8 _*_
#
#  database

from mongoconn import mongoset
# TODO to choose which database to use, when debugging, use DB = 'debug1' ,
# when getting production data, use DB = 'openpositiondb'
DB = 'positiondb'
# DB = 'debug1'

# 存储职位信息的数据表
TBPOS = 'posinfo'

DBPOS = mongoset(DB, TBPOS)

DBPOSBK = mongoset(DB, 'posinfobk')

REPOS = mongoset(DB, 'posinfo_refine')