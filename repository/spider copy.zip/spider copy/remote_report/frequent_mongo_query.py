# db.posinfo.find({"position_url":{"$in":['https://www.zhipin.com/job_detail/1407293933.html']}})

# db.posinfo_refine.find({"position_url":{"$in":['https://www.liepin.com/job/197554328.shtml']}})

from spider.database import dbproxy,DBPOS

# 通过职位url 查找某个数据
debugurl = 'https://www.liepin.com/job/197908507.shtml'

'''
{'position_url': {'$regex': 'zhipin'}}
'''

pipeline = [
        {'$match': {'position_url': {'$in': [debugurl]}}},
    ]
for item in DBPOS.aggregate(pipeline):
    for key in item.keys():
        print(key ,' : ', item[key])






