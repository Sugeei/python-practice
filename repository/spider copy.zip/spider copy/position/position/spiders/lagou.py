# -*- coding: utf-8 -*-
import scrapy

from position.settings import KEYS, CITIES

from position.items import PositionItem
from datetime import datetime
from position.timetransformer import transform_timeformat
# from position.settings import KEY as searchkeywords
from scrapy.selector import Selector


# city = ['广州','北京','上海','深圳','杭州']
class LagouSpider(scrapy.Spider):
    name = "lagou"
    allowed_domains = ["lagou.com"]
    start_urls = ['http://lagou.com/']

    def parse(self, response):
        pass

    def start_requests(self):
        search_fields = [u'']
        # search_fields = self.query
        urls = ['https://www.lagou.com/jobs/positionAjax.json?px=default&city={}&needAddtionalResult=false'.format(city) for city in CITIES]
        urls = []
        for key in KEYS:
            for city in CITIES:
                # urls.append('https://www.lagou.com/jobs/list_{}?px=default&city={}#filterBox'.format(key, city))
                yield scrapy.Request(url='https://www.lagou.com/jobs/list_{}?px=default&city={}#filterBox'.format(key, city), callback=self.parse)

        # for url in urls:
        #     yield scrapy.Request(url=url, callback=self.parse)


    def parse(self, response):
        job_urls = response.xpath('//a[@class="position_link"]/@href').extract()
        for job_url in job_urls:
            yield scrapy.Request(url=job_url, callback=self.parse_job_info)

        # next_page_url = response.xpath('//a[text()="下一页"]/@href').extract_first()
        # if next_page_url is not None:
        #     next_page_url = response.urljoin(next_page_url)
        #     yield scrapy.Request(next_page_url, callback=self.parse)

    def parse_job_info(self, response):
        item = PositionItem()
        job = Selector(response)

        item['position_url'] = response.url
        item['company_name'] = job.xpath('//div[@class="company"]/text()').extract()
        item['position_name'] = job.xpath(
            '//div[@class="ceil"]/div[@class="ceil-content"]/span[@class="ceil-job"]/text()').extract()
        industryField = \
        job.xpath('//div[@class="content_r"]/dl[@id="job_company"]/dd/ul[@class="c_feature"]/li[1]/text()').extract()[1]
        item['industry'] = "NULL" if industryField == [] else industryField
        financeStage = \
        job.xpath('//div[@class="content_r"]/dl[@id="job_company"]/dd/ul[@class="c_feature"]/li[2]/text()').extract()[1]
        item['company_level'] = "NULL" if financeStage == [] else financeStage
        side_result = response.xpath(
            '//div[@class="content_r"]/dl[@id="job_company"]/dd/ul[@class="c_feature"]/li').extract()
        # to address the proplem of unknown size of terms
        if len(side_result) == 4:
            item['company_size'] = job.xpath(
                '//div[@class="content_r"]/dl[@id="job_company"]/dd/ul[@class="c_feature"]/li[3]/text()').extract()[1]
            item['company_homepage'] = job.xpath(
                '//div[@class="content_r"]/dl[@id="job_company"]/dd/ul[@class="c_feature"]/li[4]/a/text()').extract()
        elif len(side_result) == 5:
            item['company_size'] = job.xpath(
                '//div[@class="content_r"]/dl[@id="job_company"]/dd/ul[@class="c_feature"]/li[4]/text()').extract()[1]
            item['company_homepage'] = job.xpath(
                '//div[@class="content_r"]/dl[@id="job_company"]/dd/ul[@class="c_feature"]/li[5]/a/text()').extract()
        else:
            item['company_size'] = "NULL"
            item['company_homepage'] = "NULL"
        item['temptation'] = job.xpath(
            '//div[@id="container"]/div[@class="content_l fl"]/dl/dd[@class="job-advantage"]/p/text()').extract()
        item['salary'] = job.xpath(
            '//div[@class="ceil"]/div[@class="ceil-content"]/span[@class="ceil-salary"]/text()').extract()
        position_head = job.xpath('//dd[@class="job_request"]/p/span/text()').extract()
        try:
            item['location'] = position_head[1]
            item['position_type'] = position_head[4]
            item['degree'] = position_head[3]
            item['year_experience'] = position_head[2]
        except Exception:
            pass

        item['professionalRequirement'] = job.xpath(
            '//div[@id="container"]/div[@class="content_l fl"]/dl/dd[@class="job_bt"]/div/p/text()').extract()

        item['job_description'] = job.xpath(
            '//div[@id="container"]/div[@class="content_l fl"]/dl/dd[@class="job_bt"]/div/p/text()').extract()
        item['releaseDate'] = ''.join(job.xpath('//p[@class="publish_time"]/text()').extract()).split()[0]
        # to unify release time
        if len(item['publish_time']) == 3:
            daypre = int(item['publish_time'][0])
            item['publish_time'] = (datetime.datetime.now() + datetime.timedelta(days=-daypre)).strftime('%Y-%m-%d')
        elif len(item['publish_time']) == 5:
            item['publish_time'] = datetime.datetime.now().strftime('%Y-%m-%d')
        else:
            item['publish_time'] = item['publish_time']
        item['department'] = job.xpath('//div[@class="company"]/text()').extract()
        item['company_type'] = "NULL"
        # item['positionLabel'] = job.xpath('//li[@class="labels"]/text()').extract()
        item['original_site_name'] = "拉勾网"
        item['_id'] = str(item['position_url'])  # + str(item['publish_time'])
        yield item