# -*- coding: utf-8 -*-
import scrapy

from position.items import PositionItem
from datetime import datetime
from position.timetransformer import transform_timeformat
from position.settings import KEYS as searchkeywords

import re

#        上海       北京     广州
cities = ['020000','010000','030200']

class QcwySpider(scrapy.Spider):
    name = "qcwy"
    # allowed_domains = ["51job.com"]
    # start_urls = ['http://51job.com/']
    #http://search.51job.com/list/020000%252C010000,000000,0000,00,9,99,%25E6%2595%25B0%25E6%258D%25AE%25E5%2588%2586%25E6%259E%2590,2,13.html?lang=c&stype=1&postchannel=0000&workyear=99&cotype=99&degreefrom=99&jobterm=99&companysize=99&lonlat=0%2C0&radius=-1&ord_field=0&confirmdate=9&fromType=21&dibiaoid=0&address=&line=&specialarea=00&from=&welfare=
    def start_requests(self):
        urls = []
        for f in searchkeywords:
            for c in cities:
                # 'http://search.51job.com/jobsearch/search_result.php?fromJs=1&jobarea={}&keyword={}&keywordtype=2&lang=c&stype=2&postchannel=0000&fromType=1&confirmdate=9'.format('020000','数据分析')
                urls.append('http://search.51job.com/jobsearch/search_result.php?fromJs=1&jobarea={}&keyword={}&keywordtype=2&lang=c&stype=2&postchannel=0000&fromType=1&confirmdate=9'.format(c,f))

        # urls = [
        #     # 'http://search.51job.com/jobsearch/search_result.php?fromJs=1&keyword=%s&keywordtype=2&lang=c&stype=2&postchannel=0000&fromType=1&confirmdate=9' % field
        #     'http://search.51job.com/jobsearch/search_result.php?fromJs=1&jobarea=%s&keyword=%s&keywordtype=2&lang=c&stype=2&postchannel=0000&fromType=1&confirmdate=9'.format(c,f)
        #     for f,c in zip(searchkeywords, cities)
        #     ]
        for url in urls:
            yield scrapy.Request(url=url, callback=self.parse)

    def parse(self, response):
        job_urls = response.xpath('//p[@class="t1 "]//a/@href').extract()
        for job_url in job_urls:
            yield scrapy.Request(url=job_url, callback=self.parse_job_info)

        next_page_url = response.xpath('//a[text()="下一页"]/@href').extract_first()
        if next_page_url is not None:
            next_page_url = response.urljoin(next_page_url)
            yield scrapy.Request(next_page_url, callback=self.parse)

    def parse_job_info(self, response):
        item = PositionItem()
        item['position_url'] = response.url  # '/job_detail/1410591898.html'
        # //*[@id="sojob"]/div[2]/div/div[1]/div/ul/li[1]/div/div[1]/h3/a
        job_info = response.xpath('//div[@class="cn"]')

        item['position_name'] = job_info.xpath('h1/text()').extract_first()
        if item['position_name']:
            # xpath.extract_first() 返回的是一个NoneType, 如果需要做strip等处理需要先转换成str

            item['salary'] = job_info.xpath('./strong/text()').extract_first()

            # position.xpath('//*[@id="sojob"]/div[3]/div/div[1]/div[2]/ul/li[1]/div/div[2]/p[1]/a/@href').extract_first()
            item['location'] = job_info.xpath('.//span[@class="lname"]/text()').extract_first()
            item['year_experience'] = response.xpath('//span[@class="sp4"][em[@class="i1"]]/text()').extract_first()
            item['degree'] = response.xpath('//span[@class="sp4"][em[@class="i2"]]/text()').extract_first()

            item['company_name'] = job_info.xpath('p/a/text()').extract_first()

            item['company_url'] = ''
            item['industry'] = ''

            item['original_site_name'] = '前程无忧'  # u'猎聘'.encode('utf-8')

            item['_id'] = str(item['position_url'])  # + str(item['publish_time'])

            curtime = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            item['timestamp'] = curtime

            publish_time = response.xpath('//span[@class="sp4"][em[@class="i4"]]/text()').extract_first()
            publish_time = transform_timeformat(str(publish_time))
            if publish_time > curtime:
                # 某些职位页面上的发布时间为去年某个月份的时间, 会造成发布时间大于当前时间,
                # 这种情况下,将发布时间赋值为当前时间
                publish_time = curtime
            item['publish_time'] = publish_time

            detail = response.xpath('//div[@class="jtag inbox"]/p/span/text()').extract()
            item['temptation'] = ','.join(detail)
            # from scrapy.shell import inspect_response
            # inspect_response(response, self)  # Rest of parsing code.

            # item['crawldetailflag'] = False
            company_str = job_info.xpath('./p[@class="msg ltype"]/text()').extract_first()
            company_str_list = re.sub('[\t\r\n \xa0]', '', company_str).split('|')
            for company_item in company_str_list:
                if '公司' in company_item or '合资' in company_item \
                        or r'外资' in company_item or r'国企' in company_item \
                        or r'单位' in company_item:
                    item['company_type'] = company_item
                elif '人' in company_item and '0' in company_item:
                    item['company_size'] = company_item
                else:
                    item['industry'] = company_item

            position_info_list = response.xpath('//div[@class="bmsg job_msg inbox"]/text()').extract()
            item['job_description'] = ','.join(position_info_list).split()
            item['job_description'] = ''.join(''.join(position_info_list).split())

            yield item
        else:
            pass
