from database import DBPOS as table
# from companylist import companies
from set_output_title import column, headers

# regcomp = list(map(re.compile, comp_list))
from datahandler import DataHandler


if __name__ == '__main__':

    # get detail jd if crawldetailflag == True
    # 用于debug DataHandler,
    # 给定url
    debugurl = 'https://www.zhipin.com/job_detail/1410493945.html'

    pipeline = [
        {'$match': {'position_url': {'$in': [debugurl]}}},
    ]
    detailpos = DataHandler(pipeline, table)
    detailpos.get_detail_JD()

