# 入口函数 : run.py

# 数据检查, 直接在mongo中查看数据:
查看crawldetailflag标签为fasle的记录: db.posinfo.find({'crawldetailflag':{'$in':[false]}})

# 类与成员函数说明
datahandler.DataHandler

    set_crawldetailflag: 将给定pipeline筛选条件下的数据的 crawldetailflag 字段更新为True, 此标记用于标识要爬取其职位详情页面,
                         流程:
                            position spider 初始爬取的数据中无 crawldetailflag 字段。

                            所以在筛选要爬哪些职位的职位描述信息时,筛选条件中加上 not exists crawldetailflag 这一项。
                            说明没有这个字段的数据是初始爬取的数据。

                            确定要爬取哪些数据的职位详情后, 将其 crawldetailflag 设置为True, 写回数据库。

                            爬取职位详情时, 筛选那些 crawldetailflag 为True 的数据 , 并在爬取完成后 , 将其设置为False, 表示些职位详情已爬取完成。

    get_detail_JD: 从给定pipeline筛选出的数据中提取url, 访问这些详情页面, 获取职位描述并写回数据库
                         爬不到详情的记录将其 positionstatus 置为no_target_data, 不做处理
                        self.table.update_one({'_id': item['_id']}, {
                        '$set': {'positionstatus': 'no_target_data'}})

############# ##############
开发记录
############# ##############
2017.4.10
DataSelector.py calss(sitelieping) get_formated_data 添加一个变量用于判断此职位是否关闭。 如果关闭, 则返回状态码,并写回数据库,用于标识此职位已关闭
对于已关闭的职位,在数据库中保留其信息,不用删除, 只用{'positionstatus' : 'close'}标识其关闭状态。
这样在筛选职位时, 将close的职位过滤掉即可。

筛选优质职位
qualification