#!usr/bin/env python
# #_*_ coding: utf-8 _*_

import time, re
from datetime import datetime

# import pymongo
import csv
# from mongoconn import mongoset, mongoinsert,mongoupdate, TPOS
from database import DBPOS as table
# from companylist import companies
from set_output_title import column, headers

# 从库中筛选出部分数据, 访问职位页面提取职位描述

# regcomp = list(map(re.compile, comp_list))
from pipeline import pipeline

def run():
    redata = []

    # table_comp = mongoset('lieping', 'complist')
    # table_comp = TPOS
    # mongoset('openpositiondb', 'complist')

    complist = []
    #


    time = datetime.now()
    filename = 'position' + time.strftime('%Y-%m-%d') + '.xlsx'

    redata = []
    positionurl = []
    # redata.append(headers.split(','))

    count = 0

    for item in table.aggregate(pipeline):
        item['position_name'] = ''.join(item['position_name'].split())
        positionurl.append(item['position_url'])
        # 处理薪水, 换算成月薪
        salary = str(item['salary'])
        pt = re.compile(u'(\d*)')
        if pt.findall(salary):
            match = pt.search(salary)
            smin = int(match.group(1)) / 12 * 10000
            item['salary'] = str(int(smin))

        pt = re.compile(u'(\d*)-(\d*)')
        if pt.findall(salary):  # .encode('utf-8').decode('utf-8')
            match = pt.search(salary)
            smin = int(match.group(1)) / 12 * 10000
            smax = int(match.group(2)) / 12 * 10000
            item['salary'] = str(int(smin)) + '-' + str(int(smax))

        # 处理日期格式
        try:
            item['publish_time'] = time.strptime(item['publish_time'], '%Y-%m-%d').strftime('%Y/%m/%d')
        except:
            pass
        # 处理公司行业分隔符
        try:
            item['industry'] = ','.join(item['industry'].split('/'))
        except:
            pass

        # print(item.values())
        count += 1
        row = []

        for key in column.split(','):
            try:
                row.append(item[key])

            except:
                row.append('')

        if not row[0] or row[0] != 'None':
            redata.append(row)
            print(row)

    print('Total positions are :', count)

# class
if __name__ == "__main__":

    run()
    # 将筛选后的数据写回数据库, 更新其 crawldetailflag 为True
    for item in table.aggregate(pipeline):
        try:
            table.update_one({'_id': item['_id']}, {'$set': {'crawldetailflag': True}})
        except:
            pass


