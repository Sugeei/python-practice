
column = 'position_name,salary,' \
         'company_name,' \
         'location,' \
         'year_experience,' \
         'publish_time,' \
         'job_description,qualification,position_url'
