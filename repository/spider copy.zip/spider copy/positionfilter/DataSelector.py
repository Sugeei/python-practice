from timetransformer import transform_timeformat
import datetime, re
from datetime import datetime, timedelta

from urlhandler import getemtext


class dataFactory:
    def dataselector(self, webname, sourcehtml, selector):

        if  webname == "liepin":
            return sitelieping(sourcehtml, selector)
        elif webname == "lagou":
            return sitelagou(sourcehtml, selector)
        elif webname == "zhipin":
            return siteboss(sourcehtml, selector)
        else:
            pass


class website:
    def __init__(self, sourcehtml, selector):
        # return "fruit"
        self.keys = ['company',
                'firm_type',
                'firm_detail',
                'position',
                'publish_time',
                'recruit_type',
                'location',
                'package',
                'job_decri',
                'qualification',
                'contact_info',
                'original_web',
                'URL']


# TODO Selector for lieping.com
class sitelieping(website):
    def __init__(self, sourcehtml, selector):
        self.selector = {
                'company':'div.title-info h3',
                'company_icon': '',
                'firm_type':'',
                'firm_detail':'',
                'position': 'div.title-info h1',
                'recruit_type': '',
                'publish_time': 'div.job-title-left p.basic-infor span',
                'location':'div.job-title-left p.basic-infor a',
                'package':'div.job-title-left p.job-item-title',
                'job_descri':'div.main-message',
                'qualification':'div.main-message',
                'contact_info':'',
                'original_web':'',
                'URL':'',
                }
        # return "apple"

    def get_formated_data(self, soup):
        # 这是一个已结束的职位 # https://www.liepin.com/a/8874385.shtml
        # positionstatus = soup.select('div.right-control div a.btn-apply')   # 网站默认此btn 为diabled, 职位状态是动态加载的
        positionstatus = soup.select('div.title div.over') # 如果职位已关闭,则可以找到这个标签,
        # positionstatus = soup.select('//*[@id="main"]/div[2]/div/div[1]/div/a')
        info = {}
        if not positionstatus :
            filter = self.selector
            info['positionstatus'] = 'open'

            for fi in self.selector.keys():
                info[fi] = ''
                if filter[fi]:
                    try:
                        info[fi] = getemtext(soup.select(filter[fi])[0])
                    except:
                        print(fi, 'is : ',soup.select(filter[fi]))
            try:
                info['firm_detail'] = getemtext(soup.select(filter['qualification'])[2])
            except:
                pass

            try:
                publish_time = getemtext(soup.select('div.job-title-left p.basic-infor span')[1])
                # print(pub_t)

                info['publish_time'] = transform_timeformat(str(publish_time))
            except:
                pass

            # # job_decri
            # pt = re.compile(u'工作职责：(.*)[任职位]{2}要求')
            # info['job_descri'] = pt.search(info['job_descri']).group(1)
            # # qualification
            # pt = re.compile(u'[任职位]{2}要求：(.*)')
            # info['qualification'] = pt.search(info['qualification']).group(1)
            try:
                info['package'] = info['package'].split()[0]
            except:
                pass

            # try get company icon
            # #job-view-enterprise > div.wrap.clearfix > div.clearfix > div.side > div:nth-child(1) > div.right-post-top > div.publisher-infor > p:nth-child(1) > img
            # TODO to get company icon

            try:
                img = soup.select('div.publisher-infor p img')[0]
                info['company_icon'] = img['src']
            except:
                info['company_icon'] = ''
                pass

            info['temptation'] = ''
            try:
                tags = soup.select('div.tag-list span')
                for tag in tags:
                    info['temptation'] += getemtext(tag) + ','
            except:
                pass

            return info
        else:
            return {'positionstatus' : 'close'}


# TODO selector for lagou.com
class sitelagou(website):
    def __init__(self, sourcehtml, selector):
        # return "banana"
        self.selector = {
                'company':'div.company',
                'firm_type':'',
                'firm_detail':'',
                'position': 'div.job-name span.name',
                'recruit_type': '',
                'publish_time': 'p.publish_time',
                'location':'div.job-title-left p.basic-infor a',
                'package':'dd.job_request span.salary',
                'job_decri':'dd.job_bt p',
                'qualification':'div.main-message',
                'contact_info':'',
                'original_web':'',
                'URL':'',
                }

    def get_formated_data(self, soup):

        filter = self.selector
        info = {}
        keys = ['company',
                     'firm_type',
                     'firm_detail',
                     'position',
                     'publish_time',
                     'recruit_type',
                     'location',
                     'package',
                     'job_decri',
                     'qualification',
                     'contact_info',
                     'original_web',
                     'URL']

        for fi in keys:
            info[fi] = ''
            if filter[fi]:
                try:
                    info[fi] = getemtext(soup.select(filter[fi])[0])
                except:
                    print(soup.select(filter[fi]))

        # TODO format job description
        try:
            words = [getemtext(item) for item in soup.select(filter['job_decri'])]
            info['job_decri'] = (' ').join(words)

            info['qualification'] = info['job_decri']
            # info['location'] = getemtext(soup.select(filter['package'])[1])
            # info['firm_detail'] = getemtext(soup.select(filter['qualification'])[2])
        except:
            pass
        # TODO get location
        try:
            info['location'] = getemtext(soup.select('dd.job-request span')[1])
            # info['location'] = getemtext(soup.select(filter['package'])[1])
            # info['firm_detail'] = getemtext(soup.select(filter['qualification'])[2])
        except:
            pass

        # TODO get formatted date
        try:
            pub_t = getemtext(soup.select(filter['publish_time'])[0])
            pub_t = pub_t.split()[0]
            print(pub_t)
            timenow = datetime.now()
            formattime = timenow
            if re.match('\d*-\d*-\d', pub_t):
                info['publish_time'] = pub_t
            elif re.match(u'天前', pub_t):
                pt = re.compile(u'(\d)天前')
                days = pt.findall(pub_t)[0]
                if pt.findall(pub_t): formattime = timenow - timedelta(days=int(days))
                info['publish_time'] = formattime.strftime('%Y-%m-%d')
            else:
                info['publish_time'] = formattime.strftime('%Y-%m-%d')

        except:
            pass

        return info

# TODO selector for bosszhipin.com
class siteboss(website):
    def __init__(self, sourcehtml, selector):

        self.selector = {
            'company': 'div.info-comapny p',
            'firm_type': '',
            'firm_detail': '',
            'position': 'div.info-primary div.name a',
            'recruit_type': '',
            'publish_time': 'div.info-primary span.time',
            'location': 'div.c_property p.info',
            'package': 'div.info-primary div.name a span',
            'job_descri': 'div.detail-content div.job-sec div.text',
            'qualification': 'div.detail-content div.job-sec div.text',
            'contact_info': '',
            'original_web': '',
            'URL': '',
            'temptation': '',
        }

    def get_formated_data(self, soup):
        info = {}
        # //*[@id="main"]/div[2]/div/div[1]/div/a
        positionstatus = soup.select('div.detail-op div.btns a.btn-startchat')[0]
        # positionstatus = soup.select('//*[@id="main"]/div[2]/div/div[1]/div/a')
        if positionstatus:
            info['positionstatus'] = 'open'
            filter = self.selector

            for fi in self.selector.keys():
                info[fi] = ''
                if filter[fi]:
                    try:
                        info[fi] = getemtext(soup.select(filter[fi])[0])
                    except:
                        print(soup.select(filter[fi]))

            if re.search(r'\d\d月\d\d日', info['publish_time']):
                publish_time = re.search(r'\d\d月\d\d日', info['publish_time']).group(0)
                info['publish_time'] = transform_timeformat(str(publish_time))
            try:
                info['job_descri'] = getemtext(soup.select(filter['job_descri'])[0])
            except:
                pass

            # a = info['location'].split('|', 1)[1]
            try:
                info['qualification'] = info['location'].split('|', 1)[1] + '|' + info['job_decri']
            except:
                pass

            try:
                info['location'] = info['location'].split('|')[0]
            except:
                pass

            info['original_web'] = u'boss直聘'

            # get company icon
            # '#main > div.job-banner > div > div > div.info-comapny > div > a > img'
            # a=soup.select(filter['job_decri'])[1]
            img = soup.select('div.info-comapny > div > a > img')[0]
            try:
                info['company_icon'] = img['src']
            except:
                pass

            # try:
            #     info['temptation'] = soup.select('div.tag-list span')
            # except:
            #     info['temptation'] = ''
            return info
        else:
            return {'positionstatus' : 'close'}

if __name__ == "__main__":
    pass