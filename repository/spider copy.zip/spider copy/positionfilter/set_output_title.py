#!usr/bin/env python
# #_*_ coding: utf-8 _*_

column = 'position_name,salary,' \
         'company_name,' \
         'location,' \
         'year_experience,' \
         'publish_time,' \
         'job_descri,qualification,position_url,crawldetailflag,'

headers = '''职位名称,薪水,公司名称,工作地点,工作经验(年),发布日期,工作职责,任职要求,职位链接,标签'''