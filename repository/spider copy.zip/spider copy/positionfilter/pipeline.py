#!usr/bin/env python
# #_*_ coding: utf-8 _*_

import time, re
from datetime import datetime

from companylist import companies


# 2014.04.08
# 定义pipeline, 筛选出符合下面条件的 职位信息, 用于将这些职位信息的crawldetailflag字段标记为True, 进而访问其url, 提取详细职位描述。
# 条件之一为qualification 不存在的数据


# Todo pipeline 去重
'''

['人工智能软件开发工程师', '10000-20000', '数据堂', '北京', '1年工作经验', '2017/04/04', '', '', 'https://www.liepin.com/job/197803016.shtml', False, '']
['人工智能软件开发工程师', '10000-20000', '数据堂', '北京', '1年工作经验', '2017/04/05', '', '', 'https://www.liepin.com/job/197803016.shtml', False, '']
['人工智能软件开发工程师', '10000-20000', '数据堂', '北京', '1年工作经验', '2017/04/07', '', '', 'https://www.liepin.com/job/197803016.shtml', False, '']
'''
from datetime import datetime, timedelta
curdate = datetime.now()
mindate = curdate - timedelta(days=3)  # 有的职位的发布日期一直在更新, 这样可以将优质的职位筛选出来, 方便更新其发布日期, 使其保持活跃状态
mindate = mindate.strftime('%Y-%m-%d')
#

pipeline = [
    # match
    {'$match': {'publish_time': {'$gt': mindate}}},
    {'$match': {'publish_time': {'$regex': '20'}}},
    # 匹配 crawldetailflag 为False 的row
    # {'$match': {'crawldetailflag': {'$in': [False]}}},
    # {'$match': {'salary': {'$regex': '\d'}}},
    # {'$match': {'crawldetailflag': {'$nin':[False]}}},  # 筛选出没有 crawldetailflag 字段的数据
    {'$match': {'crawldetailflag': {'$exists':0}}},  # 筛选出没有 crawldetailflag 字段的数据
    {'$match': {'positionstatus': {'$nin': ['close']}}},  # positionstatus 不为close
    # {'$match': {'job_description': {'$exists':0}}},  # 筛选出没有 job_description 字段的数据
    {'$match': {'location': {'$in': ['北京', '上海', '广州', '深圳', '杭州']}}},
    # {'$match': {'company_name': {'$in': companies}}},
    # {'$match': {'original_site_name': {'$in': ['猎聘','']}}},
    {'$match': {'degree': {'$regex': "[本硕]"}}},
    # {'$match': {'year_experience': {'$regex': "[3-4]{1}"}}},
    # {'$match': {'position_name': {'$regex': "[数据]"}}},
    {'$match': {'position_name': {'$regex': "[数据AI机器智能]"}}},
    #   #
    # {'$project': {'_id':0,'publish_time':1, 'position_name':1,}},
    # {'$gt': {'publish_time': '2016-12-01'}},
    # {'$match': {'saletime': ''}},
    # {'$match': {'company': {"$in": regcomp}}},
    # {'$group': {'_id': {'$slice': ['$address', 1, 1]}, 'counts': {'$sum': 1}}}

    # sort
    # {'$sort': {'year_experience': 1}},
]
