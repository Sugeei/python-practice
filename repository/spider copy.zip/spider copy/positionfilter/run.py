from spider.database import DBPOS as table
# from companylist import companies

# regcomp = list(map(re.compile, comp_list))
from pipeline import pipeline
from datahandler import DataHandler


if __name__ == '__main__':

    # set set_crawldetailflag
    position = DataHandler(pipeline, table)
    position.set_crawldetailflag()
    # get detail jd if crawldetailflag == True
    detailpos = DataHandler([{'$match': {'crawldetailflag': {'$in': [True]}}},], table)
    detailpos.get_detail_JD()

