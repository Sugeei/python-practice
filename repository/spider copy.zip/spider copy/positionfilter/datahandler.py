#!usr/bin/env python
# #_*_ coding: utf-8 _*_

import time, re
import random
from DataSelector import dataFactory
from urlhandler import get_soup


class DataHandler(object):

    def __init__(self, pipeline, table):
        self.table = table
        self.data = table.aggregate(pipeline)

    def set_crawldetailflag(self):
        for item in self.data:
            print('to get detail JD of this position', item['position_url'])
            try:
                self.table.update_one({'_id': item['_id']}, {'$set': {'crawldetailflag': True}})
            except:
                pass

    def get_detail_JD(self):
        for item in self.data:
            # item['position_name'] = ''.join(item['position_name'].split())
            sleeptime = random.randint(5, 20)
            # positionurl.append(item['position_url'])
            url = item['position_url']
            print('current url is: ', url)
            # url = 'https://www.liepin.com/job/197554328.shtml'
            factory = dataFactory()
            # pattern = re.compile('www\.(.*)\.com')
            # webflag = pattern.findall(item, 1)

            # 从url 中提取网站名称
            webflag = re.search(r'www\.(.*)\.com', url).group(1)
            webitem = factory.dataselector(webflag, '', '')

            # 发起request 请求页面
            soup = get_soup(url)
            # soup = get_wrapper(item, 'div.about-position')
            # pattern = re.compile(r'404')

            # TODO 从读到的soup中尝获取目标字段
            data = ''
            # data = webitem.get_formated_data(soup)
            try:
                data = webitem.get_formated_data(soup)
            except:
                pass

            # TODO 如果data为空，说明此网页过期或者访问失败，则跳过以下步骤，并将此url标记为已访问
            if data:
                try:
                    # countinfo_after = tinfo.count()
                    self.table.update_one({'_id': item['_id']}, {'$set': {'temptation':data['temptation'],'job_description': data['job_descri'],'company_icon':data['company_icon']}})
                    self.table.update_one({'_id': item['_id']}, {'$set': {'publish_time':data['publish_time']}})

                except:
                    # self.table.update_one({'_id': item['_id']}, {'$set': {'positionstatus': data['positionstatus']}})
                    pass

            else:
                # 当页面中无目标数据时, 将此职位标记为不可达
                data = {}
                data['positionstatus'] = 'no_target_data'
                #self.table.update_one({'_id': item['_id']}, {'$set': {'positionstatus': 'no_target_data'}})
                    # urls.update_one({'itemurl': url}, {'$set': {'flag': True}})

            self.table.update_one({'_id': item['_id']},
                                  {'$set': {'crawldetailflag': False, 'positionstatus': data['positionstatus']}})

            # print('sleep:', sleeptime, 's')
            # time.sleep(sleeptime)
