#!usr/bin/env python
# #_*_ coding: utf-8 _*_

import time, re
from datetime import datetime

import pymongo
import csv
# from xlswriter import excelwriter
# from mongoconn import mongoset, mongoinsert,mongoupdate, TPOS

# from companylist import companies

import time, re, random
# import pymongo


# from mongoconn import mongoset, mongoinsert,mongoupdate
from urlhandler import get_soup
# from urlhandler import get_nav_urls, get_page_urls, get_item_urls, get_wrapper, get_soup

# from mongoconn import TURL as urls
# from mongoconn import TPOS as tinfo

from DataSelector import dataFactory



# comp_list = ['数据堂','亮风台','图普','图灵','腾云天下','格灵深瞳']
# regcomp = list(map(re.compile, comp_list))

# from pipeline import pipeline

redata = []

# table_comp = mongoset('lieping', 'complist')
# table_comp = TPOS
# mongoset('openpositiondb', 'complist')

complist = []
#
# for item in table_comp.find():
#
    # complist.append(item['company'])


# curtime = datetime.now()
# filename = 'position' + curtime.strftime('%Y-%m-%d') + '.xlsx'

# redata = []
positionurl = []
# redata.append(headers.split(','))
# 获取 crawldetailflag 为True 的数据的 detail 职位详情页
import random


from database import DBPOS as table

# 2017.04.08
# 找出所有 crawldetailflag标签为True 的行, 提取其职位描述

for item in table.aggregate([{'$match': {'crawldetailflag': {'$in': [True]}}},]):
    item['position_name'] = ''.join(item['position_name'].split())
    positionurl.append(item['position_url'])

    url = item['position_url']
    print(url)
    sleeptime = random.randint(5, 20)
    factory = dataFactory()
    # pattern = re.compile('www\.(.*)\.com')
    # webflag = pattern.findall(item, 1)
    webflag = re.search(r'www\.(.*)\.com', url).group(1)
    webitem = factory.dataselector(webflag, '', '')
    soup = get_soup(url)
    # soup = get_wrapper(item, 'div.about-position')
    # pattern = re.compile(r'404')
    # TODO 从读到的soup中尝获取目标字段
    data = ''
    data = webitem.get_formated_data(soup)
    try:
        data = webitem.get_formated_data(soup)
    except:
        pass
    # TODO 如果data为空，说明此网页过期或者访问失败，则跳过以下步骤，并将此url标记为已访问
    if data:
        # print(url)
        # data['URL'] = url
        # data['_id'] = data['URL'] + data['publish_time']
        print(data)
        # tinfo.insert_one(data)
        # countinfo_after = tinfo.count()
        # print('inserted data: ' + str(countinfo_after - countinfo))
        try:
            # countinfo_after = tinfo.count()
            table.update_one({'_id': item['_id']}, {'$set': {'job_description': data['qualification'], }})
            table.update_one({'_id': item['_id']}, {'$set': {'crawldetailflag': False}})
            # print('inserted data: ' + str(countinfo_after - countinfo))

        except pymongo.errors.DuplicateKeyError:
            pass
        except:
            pass
            # urls.update_one({'itemurl': url}, {'$set': {'flag': True}})
    time.sleep(sleeptime)
    print('sleep:' , sleeptime, 's')


# print('Total positions are :', len(redata))


# 将筛选后的数据写回数据库, 更新其 crawldetailflag 为True



# excelwriter(headers.split(','), redata, filename)

