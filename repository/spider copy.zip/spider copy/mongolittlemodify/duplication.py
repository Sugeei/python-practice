from database import DBPOSBK as tar
from database import DBPOS as src
from database import REPOS as target

# 去掉posinfo 表中的重复数据 , 搞定
for item in src.find():
    try:
        item['_id'] = item['position_url']
        try:
            tar.insert_one(item)
        except:
            pass
    except:
        pass