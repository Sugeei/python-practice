# db.posinfo.find({'temptation':[]})

#!usr/bin/env python
# #_*_ coding: utf-8 _*_

import time, re
from datetime import datetime

# import pymongo
import csv
# from mongoconn import mongoset, mongoinsert,mongoupdate, TPOS
# from companylist import companies

from database import DBPOS as table


# regcomp = list(map(re.compile, comp_list))

# pipeline = [
#     {'$match': {'temptation': {'$in': }}},
# ]
for item in table.find({'temptation':[]}):
    table.update_one({'_id': item['position_url']}, {'$set': {'temptation':''}})

