from database import DBPOSBK as tar
from database import DBPOS as src
from database import REPOS as target

# # 去掉posinfo 表中的重复数据 , 搞定
# for item in src.find():
#     try:
#         item['_id'] = item['position_url']
#         try:
#             tar.insert_one(item)
#         except:
#             pass
#     except:
#         pass

# posinfo 中所有数据备份到posinfobk表中
# for item in src.find():
#     tar.insert_one(item)

# 将posinfo 中的数据全部取出, 以position_url 为id, 重新写入到表 posinfo_refine中
# for item in src.aggregate([{'$match': {'timestamp':{'$exists': 1}}},{'$match': {'position_name':{'$exists': 1}}},{'$match': {'position_name':{'$nin': ['None']}}}]):
#     if item['_id']!='null' : #and item['position_name'] != 'None':
#         try:
#             item['_id'] = item['position_url']
#             item['position_name'] = ''.join(item['position_name'].split())
#             try:
#                 target.insert_one(item)
#             except:
#                 if item['job_description']:
#                     target.update_one({'_id': item['_id'] }, {'job_description': item['job_description']})
#                 pass
#         except:
#             pass

# 将posinfo_refine中的数据保存到posinfo 中,
# for item in target.find():
#     src.insert_one(item)

# 将所有有 crawlflag字段的数据置为True .