#!usr/bin/env python
#_*_ coding: utf-8 _*_
#
#  connect mongodb

import pymongo
# from database import DB, TBPOS


def mongoset(db, table):
    # client = pymongo.MongoClient('mongodb://root:root@139.220.193.133:27017/')
    client = pymongo.MongoClient('localhost', 27017)
    data = client[db]
    sheet = data[table]
    return sheet

def mongoinsert(table, data):
    table.insert_many(data)
    try:
        table.insert_many(data)
    except:
        pass

def getmongosize(table):
    return table.find().count()

def mongoupdate(table, key, value):
    table.update(key, value)
    try:
        table.update(key, value)
    except:
        pass

