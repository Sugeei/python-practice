#!usr/bin/env python
#_*_ coding: utf-8 _*_
#
#  database

from spider.mongodb_conn import mongoset
# TODO to choose which database to use, when debugging, use DB = 'debug1' ,
# when getting production data, use DB = 'openpositiondb'
DB = 'positiondb'
# DB = 'debug1'

# 存储职位信息的数据表
TBPOS = 'posinfo'
# TBPOS = 'test'
DBPOS = mongoset(DB, TBPOS)

# TURL.create_index([('itemurl', pymongo.DESCENDING)], unique=True)
dbproxy = mongoset(DB, 'proxy')