from spider.database import dbproxy


PROXIES = []
for proxy in dbproxy.find({'status':True}):
    PROXIES.append(proxy['_id'])

